"""
robot_controller.py

Robot action controller.
"""


class RobotController:

    def __init__(self):

        self.busy = False

    def execute(self, task):

        self.busy = True

        print("=" * 50)
        print("[Robot] New Delivery Task")
        print(f"Item   : {task['item']}")
        print(f"Target : {task['target']}")
        print("=" * 50)

        # TODO
        # 1. Go to teacher station
        # 2. Wait for teacher to load the requested item
        # 3. Return to the child
        # 4. Wait for the child to take the item
        # 5. Resume patrol

        self.busy = False