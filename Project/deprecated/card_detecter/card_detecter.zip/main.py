"""
main.py

Classroom Request Card Detection
"""

import cv2

from camera import Camera

from card_detector import CardDetector

from request_manager import RequestManager

from robot_controller import RobotController

from task_queue import TaskQueue

from state_machine import StateMachine


def main():

    # 初始化
    camera = Camera(
    "http://100.84.2.68:8080/?action=stream"
    )

    detector = CardDetector()

    request_manager = RequestManager()

    robot = RobotController()

    task_queue = TaskQueue()

    while True:

        # 获取摄像头画面
        frame = camera.read()

        if frame is None:
            break

        # 检测新的请求（只有确认5帧后才会返回）
        results = detector.detect(frame)

        # 处理新的请求
        for result in results:

            request = result["request"]

            task = request_manager.create_task(result)

            task_queue.add(task)

            print("=" * 50)
            print(f"Task : {task}")
            print("Added to Task Queue")
            print("=" * 50)
            # 后续这里可以发送给机器人控制程序
            # robot.handle_request(result)
        
        if (not robot.busy) and task_queue.has_task():

            robot.execute(task_queue.next_task())
        # 绘制检测结果
        frame = detector.draw(frame)

        # 显示画面
        cv2.imshow("Classroom Assistant", frame)

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break
        
    # 释放资源
    camera.release()

    cv2.destroyAllWindows()


if __name__ == "__main__":

    main()