"""
state_machine.py

Robot task state machine.
"""

from enum import Enum


class RobotState(Enum):

    PATROL = 0

    WAIT_CARD = 1

    GO_TEACHER = 2

    WAIT_LOADING = 3

    GO_CHILD = 4

    WAIT_UNLOAD = 5

    RETURN_PATROL = 6


class StateMachine:

    def __init__(self):

        self.state = RobotState.PATROL

        self.task = None

    def get_state(self):

        return self.state

    def set_state(self, new_state):

        print(f"[STATE] {self.state.name} -> {new_state.name}")

        self.state = new_state

    def set_task(self, task):

        self.task = task

    def get_task(self):

        return self.task

    def clear_task(self):

        self.task = None